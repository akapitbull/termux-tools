/*
 * Copyright (c) 2006-2018 Wade Alcorn - wade@bindshell.net
 * Browser Exploitation Framework (BeEF) - http://beefproject.com
 * See the file 'doc/COPYING' for copying permission
 */

import java.io.*;  
import java.util.*;
import java.net.*;
import java.applet.*;

// Keith Lee
// Twitter: @keith55
// http://milo2012.wordpress.com
// keith.lee2012[at]gmail.com

public class checkJava extends Applet{  
 	public static int results = 0;
	public void init() {
	}
        public int getInfo() {
		results = 1;
		return results;
	}
}	
